# SuperHeroHunter

Hello This is a super hero hunting app which basically helps fans like me to search about their favourite superhero and can add it in your favourites section where you can remove the added superhero as well. In this project I have used HTML , CSS , JavaScript and Bootstrap. I Hope you enjoy this project. P.S: Spiderman is my favourite superhero.
